# Shelf Price detection > To be downloaded
https://universe.roboflow.com/object-detection-y9n6q/shelf-price-detection-3wzwq

Provided by a Roboflow user
License: CC BY 4.0

